export const AppColors = {
  primaryColor: '#FF565E',
  backgroundColor: '#FEFCF7',
  borderColor: '#EEEEEE',
  black: '#000000',
  white: '#FFFFFF',
  deleteColor: '#EF5350',
  stepperBorderColor: '#333F4C',
  iconColor: '#2F3D4C',
  errorColor: '#FF0000',
  green: '#00D100'
}
