// import React from "react";
import './style.css'
import Edit from './Assets/basil_edit-outline.png'
import Delete from './Assets/fluent_delete-48-regular.png'
import Printer from './Assets/Frame 1321315357.png'
import DownArrow from './Assets/icon-park-outline_down.png'

const Orders = () => {
  return (
    <div className="ordersContainer">
      <div className="orderContent">
        Orders #34562
        <div className="orders">
          <div className="header">
            <div className="headerContent">
              <div className="headerName">Item Name</div>
              <div className="headerQuantity">Quantity</div>
              <div className="headerPrice">Total Price</div>
            </div>
          </div>
          <div className="orderValues">
            <div className="item">
              <div className="itemName">
                CHESSE DABELI Price: 45
                <div>
                  <img src={Edit} />
                </div>
              </div>

              <div className="itemQuantity">- 2 +</div>
              <div className="totalPrice">
                <div className="totalPriceValue">200.00 RS</div>
                <div className="deleteItem">
                  <img src={Delete} />
                </div>
              </div>
            </div>
            <div className="item">
              <div className="itemName">
                CHESSE DABELI Price: 45{' '}
                <div>
                  <img src={Edit} />
                </div>
              </div>
              <div className="itemQuantity">- 2 +</div>
              <div className="totalPrice">
                <div className="totalPriceValue">200.00 RS</div>
                <div className="deleteItem">
                  <img src={Delete} />
                </div>
              </div>
            </div>
            <div className="item">
              <div className="itemName">
                CHESSE DABELI Price: 45{' '}
                <div>
                  <img src={Edit} />
                </div>
              </div>

              <div className="itemQuantity">- 2 +</div>
              <div className="totalPrice">
                <div className="totalPriceValue">200.00 RS</div>
                <div className="deleteItem">
                  <img src={Delete} />
                </div>
              </div>
            </div>
            <div className="item">
              <div className="itemName">
                CHESSE DABELI Price: 45{' '}
                <div>
                  <img src={Edit} />
                </div>
              </div>
              <div className="itemQuantity">- 2 +</div>
              <div className="totalPrice">
                <div className="totalPriceValue">200.00 RS</div>
                <div className="deleteItem">
                  <img src={Delete} />
                </div>
              </div>
            </div>
          </div>
          <div className="timeDate">
            <div className="timeDateContent">
              <div className="timeDateBox">
                <div className="timeDateValue">KOT 1 | Time- 15:54 | Date- 20/3/2025</div>
              </div>
              <div>
                <img src={DownArrow} />
              </div>
            </div>
            <div className="printer">
              <img src={Printer} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Orders
